import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataBase {
	String un,ps,ad,em,nc;
	public Connection connect()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Const","root","");
			return con;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	public boolean authenticate(String name, String pass,String userType)
	{
		try {
		Connection con=connect();
		Statement st=con.createStatement();
		
		String query= new String("SELECT Username, Password, Aadhaar, Email, NOC FROM "+userType+" WHERE Aadhaar = '"+name+"'");
		ResultSet rs=st.executeQuery(query);
		String s=null;
		while(rs.next())
		{
			s=rs.getString("Password");
			if(s.equals(pass))
				{
				un=rs.getString("Username");
				ad=rs.getString("Aadhaar");
				em=rs.getString("Email");
				nc=rs.getString("NOC");
				return true;
				}
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	public boolean register(String name, String pass,int Aadhaar,String Noc,String Email,String userType)
	{
		try {
			Connection conn=connect();
			Statement st= conn.createStatement();
		int i=st.executeUpdate("INSERT INTO "+userType+" (Username, Password, Aadhaar, Email, NOC) VALUES ('"+name+"', '"+pass+"', '"+Aadhaar+"', '"+Email+"', '"+Noc+"')");
		//System.out.println(i+"  kamal   "+pass);
		if(i>0)
			return true;
		else {
			
		return false;
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}
		
	}

}
